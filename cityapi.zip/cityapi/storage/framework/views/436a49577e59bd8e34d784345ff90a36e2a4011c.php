<!DOCTYPE html>
<html>
<head>
	<title>API</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

 	<!-- Подключаем Bootstrap CSS -->
  	<link rel="stylesheet" href="bt/css/bootstrap.min.css" >
	<style type="text/css">
		.card{
			margin: 25px;
			width: 600px;
		}
	</style>
</head>
<body>
	<h3 style="margin: 15px;">Использование api для <a href='https://индекс-городов.рф'>индекс городов</a></h3>
	<p class="lead" style="margin: 15px;">Ссылка на проект: <a href="https://github.com/audiowave33/cities_index">https://github.com/audiowave33/cities_index</a></p>
	



	<div class="card border-dark mb-3" style="max-width: 30rem;">
	  <div class="card-header"><h4>Получить весь список городов</h4></div>
	  <div class="card-body text-dark">
	    <h5 class="card-title" style="color:green;">GET</h5>
	    <p class="card-text">http://audiowave33.ru/api/city</p>
	  </div>
	</div>


	<div class="card border-dark mb-3" style="max-width: 30rem;">
	  <div class="card-header"><h4>Найти город по id</h4></div>
	  <div class="card-body text-dark">
	    <h5 class="card-title" style="color:green;">GET</h5>
	    <p class="card-text">http://audiowave33.ru/api/city/id</p>
	  </div>
	  <div class="card-footer bg-transparent">Пример: http://audiowave33.ru/api/city/5</div>
	</div>

	
	

	<div class="card border-dark mb-3" style="max-width: 30rem;">
	  <div class="card-header"><h4>Случайный город</h4></div>
	  <div class="card-body text-dark">
	    <h5 class="card-title" style="color:green;">GET</h5>
	    <p class="card-text">http://audiowave33.ru/api/city/random</p>
	  </div>
	</div>

	<div class="card border-dark mb-3" style="max-width: 30rem;">
	  <div class="card-header"><h4>Поиск города</h4></div>
	  <div class="card-body text-dark">
	    <h5 class="card-title" style="color:blue;">POST</h5>
	    <p class="card-text">http://audiowave33.ru/api/city/search</p>
	    <p>Параметры запроса:</p>
	    	<ul>
	    		<li>name - название города</li>
	    		<li>region - название округа или области</li>
	    	</ul>
	  </div>
	  <div class="card-footer bg-transparent">Пример №1: http://audiowave33.ru/api/city/search<br>
			name: Тюмень</div>
	  <div class="card-footer bg-transparent">Пример №2: http://audiowave33.ru/api/city/search<br>
			region: Амурская область</div>
	</div>

	
</body>
</html><?php /**PATH /var/www/u1352295/data/www/audiowave33.ru/api/resources/views/start.blade.php ENDPATH**/ ?>