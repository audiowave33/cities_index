<!DOCTYPE html>
<html>
<head>
	<title>API</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

 	<!-- Подключаем Bootstrap CSS -->
  	<link rel="stylesheet" href="bt/css/bootstrap.min.css" >
	<style type="text/css">
		.card{
			margin: 25px;
			width: 600px;
		}
	</style>
</head>
<body>
	<h3 style="margin: 15px;">Использование api для <a href='https://индекс-городов.рф'>индекс городов</a></h3>
	<p class="lead" style="margin: 15px;">Ссылка на проект: <a href="https://github.com/audiowave33/cities_index">https://github.com/audiowave33/cities_index</a></p>
	<p style="margin: 15px;">Скачать данные городов: <a href="https://audiowave33.ru/cityapi/cities.csv" download>cities.csv</a></p>
	



	<div class="card border-dark mb-3" style="width: 800px;">
	  <div class="card-header"><h4>Получить весь список городов</h4></div>
	  <div class="card-body text-dark">
	    <h5 class="card-title" style="color:green;">GET</h5>
	    <p class="card-text">http://audiowave33.ru/cityapi/public/api</p>
	    </div>
	  <div class="card-footer bg-transparent" style="white-space:pre;">Результат:
[
    {
        "id": 1,
        "name": "Красновишерск",
        "region": "Пермский край",
        "size": "Малый город",
        "climat": "условно комфортный климат",
        "population": "14,8 тыс.чел.",
        "points": 169,
        "residential and adjacent spaces": 39,
        "street networks": 30,
        "green spaces": 22,
        "public and business infrastructure and adjacent spaces": 21,
        "social and leisure infrastructure and adjacent spaces": 20,
        "citywide space": 37,
        "img": <a href="https://api.индекс-городов.рф/uploads/city/emblem/3670/thumb_327_krasnovishersk.png">"https://api.индекс-городов.рф/uploads/city/emblem/3670/thumb_327_krasnovishersk.png"</a>
    },
    {
        "id": 2,
        "name": "Касли",
        "region": "Челябинская область",
        "size": "Малый город",
        "climat": "условно комфортный климат",
        "population": "15,7 тыс.чел.",
        "points": 168,
        "residential and adjacent spaces": 30,
        "street networks": 30,
        "green spaces": 23,
        "public and business infrastructure and adjacent spaces": 27,
        "social and leisure infrastructure and adjacent spaces": 25,
        "citywide space": 33,
        "img": <a href="https://api.индекс-городов.рф/uploads/city/emblem/3612/thumb_268_Kasli_2002.png">"https://api.индекс-городов.рф/uploads/city/emblem/3612/thumb_268_Kasli_2002.png"</a>
    },
    {
        "id": 3,
        "name": "Костерево",
        "region": "Владимирская область",
        "size": "Малый город",
        "climat": "условно комфортный климат",
        "population": "8,1 тыс.чел.",
        "points": 172,
        "residential and adjacent spaces": 32,
        "street networks": 31,
        "green spaces": 23,
        "public and business infrastructure and adjacent spaces": 26,
        "social and leisure infrastructure and adjacent spaces": 21,
        "citywide space": 39,
        "img": <a href="https://api.индекс-городов.рф/uploads/city/emblem/3659/thumb_316_kosterevo.png">"https://api.индекс-городов.рф/uploads/city/emblem/3659/thumb_316_kosterevo.png"</a>
    },...
    И так далее</div>
	</div>


	<div class="card border-dark mb-3" style="width: 800px;">
	  <div class="card-header"><h4>Найти город по id</h4></div>
	  <div class="card-body text-dark">
	    <h5 class="card-title" style="color:green;">GET</h5>
	    <p class="card-text">http://audiowave33.ru/cityapi/public/api/id</p>
	  </div>
	  <div class="card-footer bg-transparent">Пример: http://audiowave33.ru/cityapi/public/api/5</div>
	  <div class="card-footer bg-transparent" style="white-space:pre;">Результат:
{
    "id": 5,
    "name": "Острогожск",
    "region": "Воронежская область",
    "size": "Малый город",
    "climat": "условно комфортный климат",
    "population": "31,8 тыс.чел.",
    "points": 179,
    "residential and adjacent spaces": 41,
    "street networks": 31,
    "green spaces": 17,
    "public and business infrastructure and adjacent spaces": 34,
    "social and leisure infrastructure and adjacent spaces": 22,
    "citywide space": 34,
    "img": <a href="https://api.индекс-городов.рф/uploads/city/emblem/3841/thumb_498_ostrogozhsk.png">"https://api.индекс-городов.рф/uploads/city/emblem/3841/thumb_498_ostrogozhsk.png"</a>
}</div>
	</div>

	
	

	<div class="card border-dark mb-3" style="width: 800px;">
	  <div class="card-header"><h4>Случайный город</h4></div>
	  <div class="card-body text-dark">
	    <h5 class="card-title" style="color:green;">GET</h5>
	    <p class="card-text">http://audiowave33.ru/cityapi/public/api/random</p>
	  </div>
	  <div class="card-footer bg-transparent" style="white-space:pre;">Результат:
{
    "id": 423,
    "name": "Лянтор",
    "region": "Ханты-Мансийский автономный округ",
    "size": "Малый город",
    "climat": "тяжелые климатические условия",
    "population": "41,2 тыс.чел.",
    "points": 171,
    "residential and adjacent spaces": 28,
    "street networks": 35,
    "green spaces": 24,
    "public and business infrastructure and adjacent spaces": 19,
    "social and leisure infrastructure and adjacent spaces": 31,
    "citywide space": 34,
    "img": <a href="https://api.индекс-городов.рф/uploads/city/emblem/3726/thumb_383_luantor.png">"https://api.индекс-городов.рф/uploads/city/emblem/3726/thumb_383_luantor.png"</a>
}
	  </div>
	</div>

	<div class="card border-dark mb-3" style="width: 800px;">
	  <div class="card-header"><h4>Поиск города</h4></div>
	  <div class="card-body text-dark">
	    <h5 class="card-title" style="color:blue;">POST</h5>
	    <p class="card-text">http://audiowave33.ru/cityapi/public/api/search</p>
	    <p>Параметры запроса:</p>
	    	<ul>
	    		<li>name - название города</li>
	    		<li>region - название округа или области</li>
	    	</ul>
	  </div>
	  <div class="card-footer bg-transparent">Пример №1: http://audiowave33.ru/cityapi/public/api/search<br>
			name: Тюмень
	</div>
			<div class="card-footer bg-transparent" style="white-space:pre;">Результат:
[
    {
        "id": 603,
        "name": "Тюмень",
        "region": "Тюменская область",
        "size": "Крупный город",
        "climat": "условно комфортный климат",
        "population": "807,3 тыс.чел.",
        "points": 225,
        "residential and adjacent spaces": 45,
        "street networks": 39,
        "green spaces": 35,
        "public and business infrastructure and adjacent spaces": 32,
        "social and leisure infrastructure and adjacent spaces": 41,
        "citywide space": 33,
        "img": <a href="https://api.индекс-городов.рф/uploads/city/emblem/4411/thumb_1069_Tyumen.cdr">"https://api.индекс-городов.рф/uploads/city/emblem/4411/thumb_1069_Tyumen.cdr"</a>
    }
]</div>
	  <div class="card-footer bg-transparent">Пример №2: http://audiowave33.ru/cityapi/public/api/search<br>
			region: Амурская область</div>
	 
	 <div class="card-footer bg-transparent" style="white-space:pre;">Результат:
[
    {
        "id": 88,
        "name": "Свободный",
        "region": "Амурская область",
        "size": "Средний город",
        "climat": "условно комфортный климат",
        "population": "54 тыс.чел.",
        "points": 143,
        "residential and adjacent spaces": 31,
        "street networks": 27,
        "green spaces": 31,
        "public and business infrastructure and adjacent spaces": 12,
        "social and leisure infrastructure and adjacent spaces": 22,
        "citywide space": 20,
        "img": <a href="https://api.индекс-городов.рф/uploads/city/emblem/4139/thumb_797_svobodniy.gif">"https://api.индекс-городов.рф/uploads/city/emblem/4139/thumb_797_svobodniy.gif"</a>
    },
    {
        "id": 131,
        "name": "Завитинск",
        "region": "Амурская область",
        "size": "Малый город",
        "climat": "условно комфортный климат",
        "population": "10,2 тыс.чел.",
        "points": 157,
        "residential and adjacent spaces": 26,
        "street networks": 33,
        "green spaces": 28,
        "public and business infrastructure and adjacent spaces": 20,
        "social and leisure infrastructure and adjacent spaces": 23,
        "citywide space": 27,
        "img": <a href="https://api.индекс-городов.рф/uploads/city/emblem/3548/thumb_203_Zavitinsk.PNG">"https://api.индекс-городов.рф/uploads/city/emblem/3548/thumb_203_Zavitinsk.PNG"</a>
    },
    {
        "id": 191,
        "name": "Райчихинск",
        "region": "Амурская область",
        "size": "Малый город",
        "climat": "условно комфортный климат",
        "population": "16,8 тыс.чел.",
        "points": 172,
        "residential and adjacent spaces": 30,
        "street networks": 28,
        "green spaces": 34,
        "public and business infrastructure and adjacent spaces": 23,
        "social and leisure infrastructure and adjacent spaces": 30,
        "citywide space": 27,
        "img": <a href="https://api.индекс-городов.рф/uploads/city/emblem/3899/thumb_556_Raychikhinsk.gif">"https://api.индекс-городов.рф/uploads/city/emblem/3899/thumb_556_Raychikhinsk.gif"</a>
    },
    {
        "id": 371,
        "name": "Белогорск",
        "region": "Амурская область",
        "size": "Средний город",
        "climat": "условно комфортный климат",
        "population": "65,3 тыс.чел.",
        "points": 162,
        "residential and adjacent spaces": 29,
        "street networks": 28,
        "green spaces": 30,
        "public and business infrastructure and adjacent spaces": 16,
        "social and leisure infrastructure and adjacent spaces": 28,
        "citywide space": 31,
        "img": <a href="https://api.индекс-городов.рф/uploads/city/emblem/4202/thumb_860_Belogorsk.png">"https://api.индекс-городов.рф/uploads/city/emblem/4202/thumb_860_Belogorsk.png"</a>
    },...
    И так далее
</div>
</div>

	
</body>
</html><?php /**PATH /var/www/u1352295/data/www/audiowave33.ru/cityapi/resources/views/start.blade.php ENDPATH**/ ?>