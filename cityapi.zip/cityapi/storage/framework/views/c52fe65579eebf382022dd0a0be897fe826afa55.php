<!DOCTYPE html>
<html>
<head>
	<title>API</title>
</head>
<body>
	<h3>Использование api для <a href='https://индекс-городов.рф'>индекс городов</a></h3>
	<p></p>
</body>
</html><?php /**PATH C:\myfiles\server\OpenServer\domains\CityApi\resources\views/start.blade.php ENDPATH**/ ?>