<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class City extends Model
{

    
    protected $fillable = [
        'name', 'region', 'size', 'climat', 'population', 'points', 'residential and adjacent spaces', 'street networks', 'green spaces', 'public and business infrastructure and adjacent spaces', 'social and leisure infrastructure and adjacent spaces', 'citywide space', 'img'
    ];

    protected $hidden = [];
    protected $table = 'cities';
}