<?php



$router->get('/', function () use ($router) {
    return view('start');
});

$router->group(['prefix' => 'api'], function () use ($router) {
	$router->get('', 'CityController@showAllCities');

	$router->get('/random', 'CityController@random');

	$router->get('/{id}', 'CityController@showOneCity');

	$router->post('/search', 'CityController@search');

});