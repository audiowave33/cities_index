<?php



$router->get('/', function () use ($router) {
    return view('start');
});

$router->group(['prefix' => 'api'], function () use ($router) {
	$router->get('city', 'CityController@showAllCities');

	$router->get('city/random', 'CityController@random');

	$router->get('city/{id}', 'CityController@showOneCity');

	$router->post('city/search', 'CityController@search');

});