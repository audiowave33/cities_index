<?php

namespace App\Http\Controllers;

use App\City;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CityController extends Controller
{

    public function showAllCities()
    {
        return response()->json(City::all())->header('Content-Type', 'application/json; charset=utf-8');;
    }

    public function showOneCity($id)
    {
        return response()->json(City::find($id));
    }

    public function random()
    {
        $id = rand(1,1116);
        return response()->json(City::find($id));
    }

    public function search(Request $request)
    {
        if (empty($request->all())){
            return response()->json('Введите запрос');
        }

        if (!empty($request->input('region')) and !empty($request->input('name'))){
            $name = $request->input('name');
            $region = $request->input('region');
            return City::where('name', 'like', '%' . $name . '%')->Where('region', 'like', '%' . $region . '%')->get();
        }

        elseif(!empty($request->input('name'))){
            $name = $request->input('name');
            return City::where('name', $name)->orWhere('name', 'like', '%' . $name . '%')->get();
        }

        elseif (!empty($request->input('region'))){
            $region = $request->input('region');
            return City::where('region', $region)->orWhere('region', 'like', '%' . $region . '%')->get();
        }

        
    }

}